package com.example.steinybear.passwordhelper2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button checkButton = (Button)findViewById(R.id.checkButton);
        checkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    checkPassword();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void checkPassword() throws IOException {
        int charPool = 0;
        double bitsOfEntropyPerChar = 0, bitsOfEntropy;
        String password = ((TextView)findViewById(R.id.passwordTextView)).getText().toString();
        String result;
        Pattern p;
        Matcher m;

        p = Pattern.compile("\\p{Lower}");
        m = p.matcher(password);
        charPool += m.find() ? 26 : 0;

        p = Pattern.compile("\\p{Upper}");
        m = p.matcher(password);
        charPool += m.find() ? 26 : 0;

        p = Pattern.compile("\\p{Digit}");
        m = p.matcher(password);
        charPool += m.find() ? 10 : 0;

        p = Pattern.compile("\\p{Punct}");
        m = p.matcher(password);
        charPool += m.find() ? 32 : 0;

        p = Pattern.compile("\\p{Space}");
        m = p.matcher(password);
        charPool += m.find() ? 1 : 0;

        bitsOfEntropyPerChar =  Math.log10(charPool) / Math.log10(2);
        bitsOfEntropy = password.length() * bitsOfEntropyPerChar;
        if(bitsOfEntropy < 28){
            result = "Very Weak";
        }
        else if (bitsOfEntropy < 36){
            result = "Weak";
        }
        else if (bitsOfEntropy < 60){
            result = "Reasonable";
        }
        else if (bitsOfEntropy < 128){
            result = "Strong";
        }
        else {
            result = "OVERKILL";
        }
        TextView resultView = (TextView)findViewById(R.id.textView2);
        resultView.setText(result);
    }
}
